<?php
require "db.php";
header("Content-Type: application/json; charset=UTF-8");

$q = $conn->query("
    SELECT suhu_air, ntu, ph, ph_status, jarak_air
    FROM realtime
    WHERE id = 1
");

if (!$q) {
    http_response_code(500);
    echo json_encode(["error" => "Query database gagal"]);
    exit;
}

$d = $q->fetch_assoc();

if (!$d) {
    echo json_encode(["error" => "Data tidak ditemukan"]);
    exit;
}

echo json_encode([
    "air"       => (float) $d["suhu_air"],
    "ntu"       => (float) $d["ntu"],
    "ph"        => (float) $d["ph"],
    "ph_status" => $d["ph_status"] ?? "NAIK",
    "jarak"     => $d["jarak_air"] !== null
        ? (float) $d["jarak_air"]
        : null
]);
?>
