<?php
$conn = new mysqli(
  "localhost",
  "akuarium",
  ";:0EWy1YYh67ma",
  "akuarium_rakka"
);


if($conn->connect_error){
  die("DB ERROR: ".$conn->connect_error);
}
$conn->query("SET time_zone = '+07:00'");

?>